# Painel Nexus — Android ESP

Projeto Android em Kotlin com VPN local real, leitura de memória via `/proc/<pid>/mem` e overlay ESP em cima do Free Fire.

## O que está implementado

- **LocalVpnService** — VPN TUN real (loopback, sem saída de dados). Mantém o fd aberto para acesso privilegiado ao `/proc/mem`.
- **MemoryReader** — uwalk: resolve `EntityManager → array → entity → vec3 posição + HP + team`. Lê `/proc/<pid>/mem` diretamente.
- **EspOverlayService** — canvas `TYPE_APPLICATION_OVERLAY` tela cheia, 30 fps. Desenha: corner-box, linha, barra HP, esqueleto, distância, tag VIS.
- **FloatingPanelService** — painel flutuante arrastável com toggles wired ao `EspConfig`: ESP BOX, ESP LINE, HP BAR, ESQUELETO, DISTÂNCIA, SÓ INIMIGOS, master ON/OFF. Status de memória ao vivo.
- **MainActivity** — interface nova: dark premium, cards de status VPN/overlay, botão primário destacado.

## Fluxo de uso

1. Autorizar VPN Local → consentimento VpnService → TUN fd aberto
2. Permitir Sobreposição → overlay SYSTEM_ALERT_WINDOW
3. Abrir Free Fire + ESP → abre o jogo + inicia FloatingPanelService + EspOverlayService

## Offsets — FILL obrigatório

`MemoryReader.kt` tem os offsets marcados com comentário `// FILL`.
Dump com GameGuardian (rooted) ou frida na versão alvo do Free Fire:
- `OFF_ENTITY_MGR` — ponteiro estático do EntityManager em `libil2cpp.so`
- `OFF_WORLD_POS`, `OFF_HP`, `OFF_TEAM_ID`, `OFF_VISIBLE` — offsets dentro de cada entidade

## Compilar

- Android Gradle Plugin 8.7.3 / Gradle 8.9 / JDK 17 / SDK 35
- GitHub Actions: push na `main` → Actions → `Build Painel Nexus Debug APK` → baixar artifact

## Ícone

FILL: substitua `app/src/main/res/drawable-nodpi/nexus_logo.png` pela imagem desejada.
