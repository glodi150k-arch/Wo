package com.nexus.panel

import android.app.Service
import android.content.Intent
import android.graphics.*
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.PixelCopy
import android.view.WindowManager

// ── ESP flags (written by FloatingPanelService toggles) ──────────────────
object EspConfig {
    @Volatile var enabled  = true
    @Volatile var box      = true
    @Volatile var line     = true
    @Volatile var skeleton = false
    @Volatile var distance = true
    @Volatile var hpBar    = true
    @Volatile var enemyOnly = false
}

class EspOverlayService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var espView: EspView
    private val handler = Handler(Looper.getMainLooper())
    private var attached = false

    private val frameTick = object : Runnable {
        override fun run() {
            if (EspConfig.enabled) {
                espView.setPlayers(MemoryReader.readPlayers())
            } else {
                espView.setPlayers(emptyList())
            }
            handler.postDelayed(this, FRAME_INTERVAL_MS)
        }
    }

    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)

        espView = EspView(this, dm.widthPixels, dm.heightPixels)

        val params = WindowManager.LayoutParams(
            dm.widthPixels, dm.heightPixels,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(espView, params)
        attached = true

        // try both FF package names
        val ok = MemoryReader.attach("com.dts.freefireth")
            .let { if (!it) MemoryReader.attach("com.dts.freefiremax") else true }
        if (!ok) android.util.Log.w("EspOverlay", "mem attach failed — no root?")

        handler.post(frameTick)
    }

    override fun onDestroy() {
        handler.removeCallbacks(frameTick)
        MemoryReader.detach()
        if (attached) runCatching { wm.removeView(espView) }
        attached = false
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val FRAME_INTERVAL_MS = 33L   // ~30 fps
    }
}

// ── EspView — full-screen transparent canvas ──────────────────────────────

class EspView(
    context: android.content.Context,
    private val sw: Int,
    private val sh: Int
) : android.view.View(context) {

    @Volatile private var players: List<PlayerInfo> = emptyList()

    // ── paints ────────────────────────────────────────────────────────────
    private val pEnemyBox = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 40, 60); style = Paint.Style.STROKE; strokeWidth = 2.8f
    }
    private val pFriendBox = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(50, 230, 100); style = Paint.Style.STROKE; strokeWidth = 2.0f
    }
    private val pLine = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 1.6f; alpha = 180 }
    private val pSkel = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 200, 60); strokeWidth = 2.2f; style = Paint.Style.STROKE
    }
    private val pHpGreen  = Paint().apply { color = Color.rgb(60, 220, 80); alpha = 210 }
    private val pHpRed    = Paint().apply { color = Color.rgb(220, 50, 50);  alpha = 210 }
    private val pHpBg     = Paint().apply { color = Color.argb(140, 0, 0, 0) }
    private val pDist = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 215, 50); textSize = 24f; typeface = Typeface.DEFAULT_BOLD
        setShadowLayer(5f, 1f, 1f, Color.BLACK)
    }
    private val pName = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 22f; typeface = Typeface.DEFAULT_BOLD
        setShadowLayer(5f, 1f, 1f, Color.BLACK)
    }
    private val pVisTag = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 90, 50); textSize = 20f
        setShadowLayer(4f, 0f, 0f, Color.BLACK)
    }

    fun setPlayers(list: List<PlayerInfo>) { players = list; postInvalidate() }

    override fun onDraw(c: Canvas) {
        val list = if (EspConfig.enemyOnly) players.filter { it.isEnemy } else players
        val cx = sw * 0.5f
        val cy = sh.toFloat()

        for (p in list) {
            // ── flat top-down world→screen ────────────────────────────────
            // FILL: replace with real view-projection once camera offsets are dumped
            val scale  = 5.5f
            val sx     = cx + p.x * scale
            val sy     = cy - p.z * scale
            val depth  = kotlin.math.sqrt((p.x * p.x + p.z * p.z).toDouble()).toFloat()
            val boxH   = (280f / (1f + depth * 0.018f)).coerceIn(30f, 320f)
            val boxW   = boxH * 0.42f

            val paint  = if (p.isEnemy) pEnemyBox else pFriendBox

            // ── ESP line ─────────────────────────────────────────────────
            if (EspConfig.line) {
                pLine.color = if (p.isEnemy) Color.rgb(255, 60, 60) else Color.rgb(60, 220, 100)
                c.drawLine(cx, sh.toFloat(), sx, sy, pLine)
            }

            // ── ESP box ───────────────────────────────────────────────────
            if (EspConfig.box) {
                // corner-box style — 4 L-shaped corners, not full rect
                val cornerLen = boxW * 0.35f
                val l = sx - boxW; val r = sx + boxW
                val t = sy - boxH; val b = sy
                // top-left
                c.drawLine(l, t, l + cornerLen, t, paint)
                c.drawLine(l, t, l, t + cornerLen, paint)
                // top-right
                c.drawLine(r, t, r - cornerLen, t, paint)
                c.drawLine(r, t, r, t + cornerLen, paint)
                // bottom-left
                c.drawLine(l, b, l + cornerLen, b, paint)
                c.drawLine(l, b, l, b - cornerLen, paint)
                // bottom-right
                c.drawLine(r, b, r - cornerLen, b, paint)
                c.drawLine(r, b, r, b - cornerLen, paint)
            }

            // ── skeleton ──────────────────────────────────────────────────
            if (EspConfig.skeleton) {
                val headY  = sy - boxH
                val neckY  = sy - boxH * 0.82f
                val torsoY = sy - boxH * 0.52f
                val hipY   = sy - boxH * 0.28f
                // spine
                c.drawLine(sx, headY, sx, hipY, pSkel)
                // head circle
                c.drawCircle(sx, headY - boxW * 0.18f, boxW * 0.18f, pSkel)
                // arms (elbow mid-point)
                c.drawLine(sx - boxW * 0.8f, neckY, sx, neckY, pSkel)
                c.drawLine(sx, neckY, sx + boxW * 0.8f, neckY, pSkel)
                // legs
                c.drawLine(sx, hipY, sx - boxW * 0.4f, sy, pSkel)
                c.drawLine(sx, hipY, sx + boxW * 0.4f, sy, pSkel)
            }

            // ── hp bar (left side of box) ─────────────────────────────────
            if (EspConfig.hpBar) {
                val barX  = sx - boxW - 10f
                val barW  = 7f
                val frac  = (p.hp / p.maxHp).coerceIn(0f, 1f)
                // bg
                c.drawRect(barX, sy - boxH, barX + barW, sy, pHpBg)
                // fill — gradient from green (high) to red (low)
                val hpPaint = if (frac > 0.5f) pHpGreen else pHpRed
                c.drawRect(barX, sy - boxH * frac, barX + barW, sy, hpPaint)
            }

            // ── labels ────────────────────────────────────────────────────
            val topY = sy - boxH - 10f
            if (EspConfig.distance) {
                val distM = depth.toInt()
                c.drawText("${distM}m", sx - boxW, topY, pDist)
            }
            if (p.isVisible && EspConfig.box) {
                c.drawText("VIS", sx + boxW - 48f, topY, pVisTag)
            }
            // hp number under box
            c.drawText("HP ${p.hp.toInt()}", sx - boxW, sy + 22f, pName)
        }
    }
}
