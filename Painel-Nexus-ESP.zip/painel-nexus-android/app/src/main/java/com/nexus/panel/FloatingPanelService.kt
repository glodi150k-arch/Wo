package com.nexus.panel

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class FloatingPanelService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var content: LinearLayout
    private lateinit var statusMem: TextView
    private lateinit var params: WindowManager.LayoutParams
    private var root: View? = null
    private var expanded = true
    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (!android.provider.Settings.canDrawOverlays(this)) { stopSelf(); return }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        // start real ESP overlay
        startService(Intent(this, EspOverlayService::class.java))
        buildPanel()
        scheduleMemStatus()
    }

    // ── panel build ───────────────────────────────────────────────────────

    private fun buildPanel() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 12, 14, 14)
            background = panelBg()
            minimumWidth = 290.dp
        }

        // header row
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, 10)
        }
        val menuBtn = tv("☰", 23f, Color.WHITE).apply {
            setPadding(0, 4, 14, 4)
            setOnClickListener {
                expanded = !expanded
                content.visibility = if (expanded) View.VISIBLE else View.GONE
            }
        }
        val titleTv = tv("NEXUS", 20f, Color.rgb(255, 50, 70)).apply {
            typeface = Typeface.DEFAULT_BOLD; letterSpacing = 0.18f
        }
        val tagTv = tv("ESP", 11f, Color.rgb(255, 50, 70)).apply {
            setPadding(8, 0, 0, 0)
            typeface = Typeface.DEFAULT_BOLD
        }
        header.addView(menuBtn)
        header.addView(titleTv, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(tagTv)
        outer.addView(header)

        // red divider
        outer.addView(divider())

        // content area
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(2, 10, 2, 4)
        }

        // ── ESP toggles ───────────────────────────────────────────────────
        content.addView(sectionLabel("── ESP VISUAL ──"))
        content.addView(toggle("ESP BOX",      true,  Color.rgb(255, 50,  60))  { EspConfig.box      = it })
        content.addView(toggle("ESP LINE",     true,  Color.rgb(255, 170, 50))  { EspConfig.line     = it })
        content.addView(toggle("HP BAR",       true,  Color.rgb(60,  220, 90))  { EspConfig.hpBar    = it })
        content.addView(toggle("ESQUELETO",    false, Color.rgb(80,  160, 255)) { EspConfig.skeleton = it })
        content.addView(toggle("DISTÂNCIA",    true,  Color.rgb(200, 200, 60))  { EspConfig.distance = it })
        content.addView(toggle("SÓ INIMIGOS",  false, Color.rgb(255, 90,  50))  { EspConfig.enemyOnly= it })

        content.addView(sectionLabel("── MEMÓRIA ──"))

        statusMem = tv("MEM: verificando...", 11f, Color.LTGRAY)
        content.addView(statusMem)

        // master ESP toggle
        content.addView(divider().apply {
            (layoutParams as LinearLayout.LayoutParams).setMargins(0, 12, 0, 8)
        })
        content.addView(masterToggle())

        outer.addView(content)

        // window params
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 14; y = 90 }

        header.setOnTouchListener(dragListener())
        root = outer
        wm.addView(outer, params)
    }

    // ── widgets ───────────────────────────────────────────────────────────

    private fun sectionLabel(txt: String) = tv(txt, 10f, Color.rgb(110, 110, 130)).apply {
        setPadding(0, 10, 0, 6)
    }

    private fun toggle(
        name: String,
        default: Boolean,
        onColor: Int,
        cb: (Boolean) -> Unit
    ): View {
        var state = default
        cb(default) // apply default to EspConfig
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 7, 0, 7)
            val nameTv  = tv(name, 13f, Color.WHITE)
            val stateTv = tv(if (default) "ON" else "OFF", 12f, if (default) onColor else Color.rgb(100,100,100)).apply {
                typeface = Typeface.DEFAULT_BOLD; setPadding(14, 5, 6, 5)
            }
            addView(nameTv, LinearLayout.LayoutParams(0, -2, 1f))
            addView(stateTv)
            setOnClickListener {
                state = !state
                stateTv.text = if (state) "ON" else "OFF"
                stateTv.setTextColor(if (state) onColor else Color.rgb(100,100,100))
                cb(state)
            }
        }
    }

    private fun masterToggle(): View {
        var on = true
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply {
                setColor(Color.argb(60, 255, 50, 70)); cornerRadius = 10f
                setStroke(1, Color.rgb(255, 50, 70))
            }
            setPadding(12, 10, 12, 10)
            val lbl  = tv("ESP MASTER", 14f, Color.WHITE).apply { typeface = Typeface.DEFAULT_BOLD }
            val stat = tv("ATIVO", 13f, Color.rgb(60, 220, 80)).apply {
                typeface = Typeface.DEFAULT_BOLD; setPadding(14, 0, 0, 0)
            }
            addView(lbl, LinearLayout.LayoutParams(0, -2, 1f))
            addView(stat)
            setOnClickListener {
                on = !on
                EspConfig.enabled = on
                stat.text = if (on) "ATIVO" else "OFF"
                stat.setTextColor(if (on) Color.rgb(60, 220, 80) else Color.rgb(180, 50, 50))
            }
        }
    }

    private fun divider() = View(this).apply {
        setBackgroundColor(Color.argb(80, 255, 50, 70))
        layoutParams = LinearLayout.LayoutParams(-1, 1)
    }

    private fun panelBg() = GradientDrawable().apply {
        setColor(Color.argb(220, 8, 4, 10))
        setStroke(2, Color.rgb(255, 40, 60))
        cornerRadius = 20f
    }

    private fun tv(text: String, size: Float, color: Int) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color)
    }

    private val Int.dp get() = (this * resources.displayMetrics.density + 0.5f).toInt()

    // ── drag ──────────────────────────────────────────────────────────────

    private fun dragListener() = object : View.OnTouchListener {
        private var ox = 0; private var oy = 0
        private var tx = 0f; private var ty = 0f
        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    ox = params.x; oy = params.y; tx = e.rawX; ty = e.rawY; return true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = ox + (e.rawX - tx).toInt()
                    params.y = oy + (e.rawY - ty).toInt()
                    root?.let { wm.updateViewLayout(it, params) }
                    return true
                }
            }
            return false
        }
    }

    // ── mem status polling ────────────────────────────────────────────────

    private fun scheduleMemStatus() {
        handler.postDelayed({
            if (::statusMem.isInitialized) {
                val ok = MemoryReader.isAttached
                statusMem.text = if (ok) "MEM: ✓ conectado" else "MEM: ✗ sem acesso (root?)"
                statusMem.setTextColor(if (ok) Color.rgb(60, 220, 80) else Color.rgb(220, 80, 60))
            }
            scheduleMemStatus()
        }, 3000L)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        stopService(Intent(this, EspOverlayService::class.java))
        root?.let { runCatching { wm.removeView(it) } }
        root = null
        super.onDestroy()
    }
}
