package com.nexus.panel

import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.system.Os
import android.util.Log

/**
 * Real TUN-based local VPN.
 * Routes all traffic through a loopback TUN fd so the process runs
 * with VPN uid privileges on the device — required for /proc/mem access
 * on some Android builds. Traffic is drained and dropped locally;
 * nothing leaves the device.
 */
class LocalVpnService : VpnService() {

    private var tun: ParcelFileDescriptor? = null
    @Volatile private var running = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stop(); return START_NOT_STICKY }
        if (tun == null) start()
        return START_STICKY
    }

    private fun start() {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        tun = Builder()
            .setSession("NexusLocal")
            .addAddress("10.88.0.1", 32)
            .addDnsServer("1.1.1.1")
            .addRoute("0.0.0.0", 0)
            .setConfigureIntent(pi)
            .establish()

        if (tun == null) { Log.e(TAG, "establish() returned null"); stopSelf(); return }

        running = true
        Log.i(TAG, "TUN fd open — draining locally")
        Thread(::drainLoop, "nexus-tun-drain").apply { isDaemon = true; start() }
    }

    // Drains IP frames from the TUN fd and discards them.
    // The VPN fd must be kept read to avoid blocking the kernel write path.
    private fun drainLoop() {
        val fd  = tun?.fileDescriptor ?: return
        val buf = ByteArray(32768)
        while (running) {
            try {
                val n = Os.read(fd, buf, 0, buf.size)
                if (n < 0) break
                // drop — no forwarding, no logging of payload
            } catch (e: Exception) {
                if (running) Log.w(TAG, "drain: ${e.message}")
                break
            }
        }
    }

    private fun stop() {
        running = false
        runCatching { tun?.close() }
        tun = null
        stopSelf()
    }

    override fun onRevoke() { stop() }
    override fun onDestroy() { stop(); super.onDestroy() }
    override fun onBind(intent: Intent?) = super.onBind(intent)

    companion object {
        const val ACTION_STOP = "com.nexus.panel.STOP_VPN"
        private const val TAG = "NexusVPN"
    }
}
