package com.nexus.panel

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.VpnService
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var cardVpn:     StatusCard
    private lateinit var cardOverlay: StatusCard
    private val REQ_VPN = 4101

    // ── palette ───────────────────────────────────────────────────────────
    private val cBg      = Color.rgb(6,  3,  9)
    private val cSurface = Color.rgb(13, 7,  16)
    private val cRed     = Color.rgb(255, 40, 60)
    private val cRedDim  = Color.rgb(140, 20, 35)
    private val cGreen   = Color.rgb(50,  210, 90)
    private val cText    = Color.rgb(230, 225, 235)
    private val cMuted   = Color.rgb(120, 115, 130)

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.statusBarColor  = cBg
        window.navigationBarColor = cBg
        buildUi()
    }

    private fun buildUi() {
        // root scroll
        val scroll = ScrollView(this).apply { setBackgroundColor(cBg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24.dp, 48.dp, 24.dp, 32.dp)
        }
        scroll.addView(root)

        // ── logo ──────────────────────────────────────────────────────────
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.nexus_logo)
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            // FILL: swap R.drawable.nexus_logo for your new icon once uploaded
        }
        root.addView(logo, LinearLayout.LayoutParams(-1, 180.dp).apply {
            setMargins(0, 0, 0, 8.dp)
        })

        // ── title block ───────────────────────────────────────────────────
        root.addView(textView("NEXUS", 32f, cRed, Typeface.DEFAULT_BOLD).apply {
            gravity = Gravity.CENTER; letterSpacing = 0.25f
        })
        root.addView(textView("FREE FIRE ESP", 13f, cMuted).apply {
            gravity = Gravity.CENTER; setPadding(0, 4.dp, 0, 28.dp)
        })

        // ── status cards ──────────────────────────────────────────────────
        cardVpn     = StatusCard("VPN LOCAL",    "Pendente", false)
        cardOverlay = StatusCard("SOBREPOSIÇÃO", "Pendente", false)
        root.addView(statusRow(cardVpn, cardOverlay))
        root.addView(spacer(20.dp))

        // ── action buttons ────────────────────────────────────────────────
        root.addView(actionBtn("AUTORIZAR VPN LOCAL")       { requestVpnPermission()     })
        root.addView(actionBtn("PERMITIR SOBREPOSIÇÃO")     { requestOverlayPermission() })
        root.addView(spacer(8.dp))
        root.addView(primaryBtn("▶  ABRIR FREE FIRE + ESP") { openGameAndPanel()         })
        root.addView(spacer(16.dp))
        root.addView(actionBtn("■  PARAR PAINEL")           {
            stopService(Intent(this, FloatingPanelService::class.java))
            stopService(Intent(this, EspOverlayService::class.java))
            toast("Painel parado.")
        })

        // ── footer ────────────────────────────────────────────────────────
        root.addView(spacer(28.dp))
        root.addView(textView("VPN local usada para manter uid privilegiado.\nLeitura de memória requer root/permissão do SO.", 11f, cMuted).apply {
            gravity = Gravity.CENTER
        })

        setContentView(scroll)
    }

    // ── status card row ───────────────────────────────────────────────────

    inner class StatusCard(title: String, status: String, ok: Boolean) {
        val root: LinearLayout
        private val statusTv: TextView
        init {
            root = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(14.dp, 12.dp, 14.dp, 12.dp)
                background = cardBg()
            }
            root.addView(textView(title, 10f, cMuted))
            statusTv = textView(status, 13f, if (ok) cGreen else cRedDim, Typeface.DEFAULT_BOLD)
            root.addView(statusTv)
        }
        fun set(text: String, ok: Boolean) {
            statusTv.text = text
            statusTv.setTextColor(if (ok) cGreen else cRedDim)
        }
    }

    private fun statusRow(a: StatusCard, b: StatusCard): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(a.root, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(0,0,8.dp,0) })
            addView(b.root, LinearLayout.LayoutParams(0, -2, 1f))
        }

    // ── button builders ───────────────────────────────────────────────────

    private fun actionBtn(label: String, action: () -> Unit) =
        TextView(this).apply {
            text = label; textSize = 14f; setTextColor(cText)
            gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 16.dp, 0, 16.dp)
            background = outlineBg(cRedDim, 2)
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0,6.dp,0,6.dp) }
        }

    private fun primaryBtn(label: String, action: () -> Unit) =
        TextView(this).apply {
            text = label; textSize = 16f; setTextColor(Color.WHITE)
            gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 20.dp, 0, 20.dp)
            background = solidBg(cRed)
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0,6.dp,0,6.dp) }
        }

    // ── drawables ─────────────────────────────────────────────────────────

    private fun cardBg() = GradientDrawable().apply {
        setColor(cSurface); cornerRadius = 16f; setStroke(1, Color.argb(60, 255, 40, 60))
    }
    private fun outlineBg(stroke: Int, w: Int) = GradientDrawable().apply {
        setColor(Color.TRANSPARENT); cornerRadius = 14f; setStroke(w, stroke)
    }
    private fun solidBg(fill: Int) = GradientDrawable().apply {
        setColor(fill); cornerRadius = 14f
    }

    // ── helpers ───────────────────────────────────────────────────────────

    private fun textView(t: String, sz: Float, col: Int, tf: Typeface = Typeface.DEFAULT) =
        TextView(this).apply { text = t; textSize = sz; setTextColor(col); typeface = tf }

    private fun spacer(h: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(-1, h)
    }

    private val Int.dp get() = (this * resources.displayMetrics.density + 0.5f).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    // ── permission logic (unchanged flow, updated status cards) ──────────

    private fun requestVpnPermission() {
        val intent = VpnService.prepare(this)
        if (intent == null) {
            cardVpn.set("Concedida", true)
        } else {
            @Suppress("DEPRECATION")
            startActivityForResult(intent, REQ_VPN)
        }
    }

    private fun requestOverlayPermission() {
        if (Settings.canDrawOverlays(this)) {
            cardOverlay.set("Concedida", true)
        } else {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).apply {
                data = android.net.Uri.parse("package:$packageName")
            })
        }
    }

    private fun openGameAndPanel() {
        if (VpnService.prepare(this) != null) { toast("Autorize a VPN primeiro."); return }
        if (!Settings.canDrawOverlays(this))  { toast("Autorize a sobreposição primeiro."); requestOverlayPermission(); return }

        // start VPN service (real TUN)
        startService(VpnService.prepare(this)?.also { startActivityForResult(it, REQ_VPN) }
            ?: Intent(this, LocalVpnService::class.java))

        val gameIntent = packageManager.getLaunchIntentForPackage("com.dts.freefireth")
            ?: packageManager.getLaunchIntentForPackage("com.dts.freefiremax")
            ?: run { toast("Free Fire não encontrado."); return }

        startService(Intent(this, FloatingPanelService::class.java))
        startActivity(gameIntent)
    }

    @Deprecated("VPN consent result")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_VPN) {
            val ok = resultCode == RESULT_OK
            cardVpn.set(if (ok) "Concedida" else "Negada", ok)
            if (ok) startService(Intent(this, LocalVpnService::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        if (::cardOverlay.isInitialized) {
            val ok = Settings.canDrawOverlays(this)
            cardOverlay.set(if (ok) "Concedida" else "Pendente", ok)
        }
        if (::cardVpn.isInitialized && VpnService.prepare(this) == null) {
            cardVpn.set("Concedida", true)
        }
    }
}
