package com.nexus.panel

import android.util.Log
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class PlayerInfo(
    val x: Float,
    val y: Float,
    val z: Float,
    val hp: Float,
    val maxHp: Float,
    val teamId: Int,
    val isEnemy: Boolean,
    val isVisible: Boolean
)

object MemoryReader {

    private const val TAG = "NexusMemReader"

    // ── Free Fire offsets (libil2cpp.so) — FILL with current dump ────────
    // Dump with GameGuardian or frida on rooted device running target ver.
    private const val OFF_ENTITY_MGR   = 0x05C2D2B0L   // FILL: EntityManager static ptr
    private const val OFF_ENTITY_ARRAY = 0x0030L        // FILL: entity array ptr inside mgr
    private const val OFF_ENTITY_COUNT = 0x0038L        // FILL: entity count (int)
    private const val OFF_ENTITY_STEP  = 0x08L          // ptr size on arm64
    private const val OFF_WORLD_POS    = 0x01A8L        // FILL: vec3 {x,y,z} float[3]
    private const val OFF_HP           = 0x0144L        // FILL: float current hp
    private const val OFF_HP_MAX       = 0x0148L        // FILL: float max hp
    private const val OFF_TEAM_ID      = 0x011CL        // FILL: int team id
    private const val OFF_VISIBLE      = 0x0260L        // FILL: byte/bool last-frame visible
    // ─────────────────────────────────────────────────────────────────────

    private var memFile: RandomAccessFile? = null
    private var libBase: Long = 0L
    private var pid: Int = -1
    private var myTeamId: Int = -1

    val isAttached get() = memFile != null && pid != -1

    fun attach(packageName: String): Boolean {
        pid = findPid(packageName) ?: run {
            Log.w(TAG, "pid not found for $packageName"); return false
        }
        libBase = findLibBase(pid, "libil2cpp.so") ?: run {
            Log.w(TAG, "libil2cpp not mapped for pid $pid"); return false
        }
        return try {
            memFile = RandomAccessFile("/proc/$pid/mem", "r")
            Log.i(TAG, "attached pid=$pid libBase=0x${libBase.toString(16)}")
            true
        } catch (e: Exception) {
            Log.e(TAG, "open /proc/$pid/mem: ${e.message}")
            false
        }
    }

    fun detach() {
        runCatching { memFile?.close() }
        memFile = null; pid = -1; libBase = 0L; myTeamId = -1
    }

    // uwalk: resolve EntityManager → array → each entity → position + stats
    fun readPlayers(limit: Int = 64): List<PlayerInfo> {
        val mem = memFile ?: return emptyList()
        return try {
            val mgrPtr   = readLong(mem, libBase + OFF_ENTITY_MGR)
            if (mgrPtr == 0L) return emptyList()
            val arrPtr   = readLong(mem, mgrPtr + OFF_ENTITY_ARRAY)
            val count    = readInt (mem, mgrPtr + OFF_ENTITY_COUNT).coerceIn(0, limit)
            if (arrPtr == 0L || count == 0) return emptyList()

            // grab own team id on first successful read
            if (myTeamId == -1 && count > 0) {
                val first = readLong(mem, arrPtr)
                if (first != 0L) myTeamId = readInt(mem, first + OFF_TEAM_ID)
            }

            (0 until count).mapNotNull { i ->
                val ptr = readLong(mem, arrPtr + i * OFF_ENTITY_STEP)
                if (ptr == 0L) return@mapNotNull null
                val hp    = readFloat(mem, ptr + OFF_HP)
                if (hp <= 0f) return@mapNotNull null
                val maxHp = readFloat(mem, ptr + OFF_HP_MAX).coerceAtLeast(1f)
                val team  = readInt  (mem, ptr + OFF_TEAM_ID)
                val px    = readFloat(mem, ptr + OFF_WORLD_POS)
                val py    = readFloat(mem, ptr + OFF_WORLD_POS + 4)
                val pz    = readFloat(mem, ptr + OFF_WORLD_POS + 8)
                val vis   = readByte (mem, ptr + OFF_VISIBLE) != 0.toByte()
                PlayerInfo(px, py, pz, hp, maxHp, team, team != myTeamId, vis)
            }
        } catch (e: Exception) {
            Log.w(TAG, "readPlayers: ${e.message}")
            emptyList()
        }
    }

    // ── raw memory primitives ─────────────────────────────────────────────

    private fun buf(mem: RandomAccessFile, addr: Long, len: Int): ByteBuffer {
        val b = ByteArray(len)
        mem.seek(addr); mem.readFully(b)
        return ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)
    }

    private fun readByte (m: RandomAccessFile, a: Long): Byte  = buf(m, a, 1).get()
    private fun readInt  (m: RandomAccessFile, a: Long): Int   = buf(m, a, 4).int
    private fun readFloat(m: RandomAccessFile, a: Long): Float = buf(m, a, 4).float
    private fun readLong (m: RandomAccessFile, a: Long): Long  = buf(m, a, 8).long

    // ── /proc helpers ─────────────────────────────────────────────────────

    private fun findPid(pkg: String): Int? =
        File("/proc").listFiles()
            ?.firstOrNull { f ->
                f.name.all(Char::isDigit) &&
                runCatching {
                    File(f, "cmdline").readText().trimEnd('\u0000')
                }.getOrNull()?.startsWith(pkg) == true
            }?.name?.toIntOrNull()

    private fun findLibBase(pid: Int, lib: String): Long? =
        runCatching {
            File("/proc/$pid/maps").readLines()
                .firstOrNull { it.contains(lib) && it.contains("r-xp") }
                ?.split("-")?.firstOrNull()?.toLong(16)
        }.getOrNull()
}
